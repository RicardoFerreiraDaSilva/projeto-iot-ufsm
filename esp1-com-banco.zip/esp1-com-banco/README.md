Este pasta contém a arquitetura de backend e o firmware de borda para o sistema de monitoramento de acesso e condições ambientais.
Evoluiu de uma solução local (Node-RED/InfluxDB) para uma solução híbrida que utiliza o Broker Público HiveMQ e o Banco de Dados PostgreSQL (Neon) na nuvem, garantindo a conectividade e o acesso compartilhado aos dados em tempo real.
Porém, o único dispositivo funcionando é o ESP1.

---

## 1. Arquitetura e Fluxo de Dados

A arquitetura final é um pipeline que centraliza a coleta de dados de múltiplos dispositivos na nuvem para facilitar a visualização no Grafana por toda a equipe.

### 1.1 Fluxo de Dados

O dado é gerado no hardware, passa por um servidor MQTT público e é processado por um agente local antes de ser armazenado e visualizado.

1.  **Geração (ESP32):** Os dispositivos de borda (ESP1, ESP2, ESP3) realizam a leitura/captura de eventos (teclado, temperatura) e **unificam a lógica de comunicação** (Wi-Fi e MQTT) no próprio firmware.
2.  **Transporte (MQTT):** O ESP publica a mensagem JSON no **Broker Público HiveMQ**, que atua como o servidor central de mensagens.
3.  **Coleta (Telegraf):** O contêiner **Telegraf** (rodando localmente) atua como *middleware de ingestão*, lendo o tópico único no Broker Público.
4.  **Armazenamento (Neon):** O Telegraf insere os dados na **Tabela SQL Mestra (`sensores_iot`)** no **PostgreSQL (Neon)**. Essa mudança facilita o **acesso remoto aos dados** para todos os membros do grupo.
5.  **Visualização (Grafana):** O Grafana lê os dados da tabela no Neon e exibe os painéis de logs e gráficos.



### 1.2 Estrutura de Dados (JSON e SQL)

O design da aplicação foi simplificado para usar um **Tópico MQTT Único** e uma **Tabela SQL Mestra**.

* **Tópico Único:** `ufsm/iot/json`
* **Chave de Identificação:** Todos os dispositivos incluem o campo `dispositivo_id` no JSON.
* **Tabela Mestra:** `sensores_iot` (no Neon)

---

## 2. Configuração e Execução

Para rodar o backend e o simulador, é necessário ter o **Docker Desktop** ativo e o **código ESP 1** atualizado.

### 2.1 Por que o Broker Público?

Optou-se por utilizar o **Broker Público HiveMQ** para garantir a conectividade dos dispositivos físicos, pois o sistema encontrou um erro persistente (`rc=-2`) que impedia a conexão do ESP32 ao Mosquitto local, provavelmente devido a bloqueios de rede no sistema operacional/firewall.

### 2.2 Requisitos e Startup

1.  **Credenciais Neon:** Obtenha a URL de conexão do PostgreSQL (Neon).
2.  **Atualização do Telegraf:** O arquivo `telegraf.conf` deve estar configurado para ler o `broker.hivemq.com` e escrever no Neon (PostgreSQL).
3.  **Startup do Backend:** Rode a stack Docker (Mosquitto/Telegraf/Grafana) para garantir que o Telegraf esteja ativo e escutando o broker.
    ```bash
    docker compose up -d
    ```

### 2.3 Validação (Prova de Conceito)

A prova de conceito foi validada para o **ESP1 (Teclado)**. Os demais ESPs (Temperatura, Porta, LEDs) na nova tabela são utilizados apenas para fins de **testes manuais de comunicação** e validação dos painéis do Grafana.

Para testar o fluxo completo:

1.  **Carregue** o código final (`broker.hivemq.com` como `mqttServer`) no ESP1 (Teclado).
2.  **Verifique a conexão:** O Monitor Serial deve mostrar `MQTT Conectado!`.
3.  **Gere dados:** Pressione `1234#` no teclado.
4.  **Confira o Grafana:** A tabela esp_1 deve atualizar, confirmando o fluxo do dispositivo físico ao Grafana.